/** Public projection only. Concrete mappings and ownership proofs stay on server. */
export type PostingPlatform = "tiktok" | "youtube" | "facebook";
export type PostingBrand = "KONG" | "Black Room";
export interface PostingAccount {
  key: string;
  platform: PostingPlatform;
  brand: PostingBrand;
  displayIdentity: string;
  identityEvidence: "coordinator_mapping" | "verified_source_metadata";
  runtimeConnection: "unknown";
  aliasesCount: number;
}
export interface PostingRegistrySnapshot {
  ownerId: string;
  status: "ready" | "unavailable";
  reason: "owner_source_binding_unproven" | "source_unavailable" | "invalid_source_records" | null;
  accounts: PostingAccount[];
  excludedUnverifiable: number;
}

import { readSource, type Source } from './agents-world';
import { worldOwnerMatches } from './agents-world-session';
import type { PostingAccount as PublicPostingAccount } from '@shared/posting-registry';

export type PostingAccount = PublicPostingAccount;

export type PostingRegistry =
  | { state: 'loading'; ownerId: string; accounts: []; excludedUnverifiable: 0 }
  | { state: 'denied'; ownerId: string; accounts: []; excludedUnverifiable: 0 }
  | { state: 'error'; ownerId: string; reason: 'source_unavailable' | 'invalid_source_records'; accounts: []; excludedUnverifiable: 0 }
  | { state: 'unavailable'; ownerId: string; reason: 'owner_source_binding_unproven' | 'source_unavailable' | 'invalid_source_records'; accounts: []; excludedUnverifiable: number }
  | { state: 'ready'; ownerId: string; reason: null; accounts: PostingAccount[]; excludedUnverifiable: number };

const REGISTRY_ENDPOINT = '/api/agents-office/posting-registry';
const MAX_ACCOUNTS = 32;
const MAX_TEXT = 96;
const safeRecord = (value: unknown): Record<string, unknown> =>
  value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
const cleanText = (value: unknown, limit = MAX_TEXT): string | null => {
  if (typeof value !== 'string') return null;
  if (value.length > limit || value.trim() !== value || /[\u0000-\u001f\u007f]/.test(value)) return null;
  return value || null;
};
const countValue = (value: unknown): number | null =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && value <= 1_000_000
    ? value
    : null;
const empty = (state: 'loading' | 'denied', ownerId: string): PostingRegistry =>
  ({ state, ownerId, accounts: [], excludedUnverifiable: 0 });

function unavailable(ownerId: string, reason: 'owner_source_binding_unproven' | 'source_unavailable' | 'invalid_source_records', excludedUnverifiable = 0): PostingRegistry {
  return { state: 'unavailable', ownerId, reason, accounts: [], excludedUnverifiable };
}

function validAccount(value: unknown): PostingAccount | null {
  const item = safeRecord(value);
  // Preserve the canonical platform/physical-identity key, not blog or display label.
  const sourceKey = cleanText(item.key, 72);
  const displayIdentity = cleanText(item.displayIdentity);
  const platform: PostingAccount['platform'] | null =
    item.platform === 'tiktok' || item.platform === 'youtube' || item.platform === 'facebook'
      ? item.platform : null;
  const brand: PostingAccount['brand'] | null =
    item.brand === 'KONG' || item.brand === 'Black Room' ? item.brand : null;
  const aliasesCount = countValue(item.aliasesCount);
  if (!sourceKey || !displayIdentity || !platform || !brand ||
      (item.identityEvidence !== 'coordinator_mapping' && item.identityEvidence !== 'verified_source_metadata') ||
      item.runtimeConnection !== 'unknown' || aliasesCount === null || aliasesCount < 1 || aliasesCount > 128 ||
      !sourceKey.startsWith(`${platform}:`) || !/^([a-z]+):(id|handle):[A-Za-z0-9_.-]+$/.test(sourceKey)) return null;
  // KONG's approved channel is TikTok only; do not surface another platform as its account.
  if (brand === 'KONG' && platform !== 'tiktok') return null;
  return {
    key: sourceKey,
    platform,
    brand,
    displayIdentity,
    identityEvidence: item.identityEvidence,
    runtimeConnection: 'unknown',
    aliasesCount,
  };
}

/** The sole posting-registry reader: verify the signed-in owner before its allowlisted request. */
export async function readPostingRegistry(ownerId: string, signal: AbortSignal): Promise<PostingRegistry> {
  if (!cleanText(ownerId, 128)) return empty('denied', ownerId);
  const auth: Source = await readSource('/api/auth/me', signal);
  if (signal.aborted) return empty('denied', ownerId);
  if (auth.state === 'denied') return empty('denied', ownerId);
  if (auth.state !== 'ready') return unavailable(ownerId, 'source_unavailable');
  if (!worldOwnerMatches(ownerId, auth)) return empty('denied', ownerId);

  try {
    const response = await fetch(REGISTRY_ENDPOINT, {
      credentials: 'same-origin',
      cache: 'no-store',
      signal,
    });
    if (signal.aborted) return empty('denied', ownerId);
    if (response.status === 401 || response.status === 403) return empty('denied', ownerId);
    if (!response.ok || !response.headers.get('content-type')?.includes('application/json')) {
      return unavailable(ownerId, 'source_unavailable');
    }
    const payload: unknown = await response.json();
    if (signal.aborted) return empty('denied', ownerId);
    const data = safeRecord(payload);
    // Never retain or display records unless the server repeats the exact authenticated owner.
    if (typeof data.ownerId !== 'string' || data.ownerId !== ownerId) return empty('denied', ownerId);
    const excludedUnverifiable = countValue(data.excludedUnverifiable);
    if (excludedUnverifiable === null || !Array.isArray(data.accounts) ||
        data.accounts.length > MAX_ACCOUNTS ||
        (data.status !== 'ready' && data.status !== 'unavailable')) {
      return unavailable(ownerId, 'invalid_source_records');
    }
    if (data.status === 'unavailable') {
      const reason = data.reason;
      if (data.accounts.length !== 0 ||
          (reason !== 'owner_source_binding_unproven' &&
          reason !== 'source_unavailable' && reason !== 'invalid_source_records')) {
        return unavailable(ownerId, 'invalid_source_records', excludedUnverifiable);
      }
      return unavailable(ownerId, reason, excludedUnverifiable);
    }
    if (data.reason !== null) {
      return unavailable(ownerId, 'invalid_source_records', excludedUnverifiable);
    }
    const accounts: PostingAccount[] = [];
    const keys = new Set<string>();
    for (const raw of data.accounts) {
      const account = validAccount(raw);
      if (!account || keys.has(account.key)) {
        return unavailable(ownerId, 'invalid_source_records', excludedUnverifiable);
      }
      keys.add(account.key);
      accounts.push(account);
    }
    return { state: 'ready', ownerId, reason: null, accounts, excludedUnverifiable };
  } catch {
    return signal.aborted ? empty('denied', ownerId) : unavailable(ownerId, 'source_unavailable');
  }
}

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { readPostingRegistry, type PostingAccount, type PostingRegistry } from '@/lib/posting-registry';
import './posting-departments.css';

type Props = { ownerId: string; refresh: number };
const loadingState = (ownerId: string): PostingRegistry => ({
  state: 'loading', ownerId, accounts: [], excludedUnverifiable: 0,
});
const reasonText: Record<'owner_source_binding_unproven' | 'source_unavailable' | 'invalid_source_records', string> = {
  owner_source_binding_unproven: 'No se pudo demostrar la vinculación de origen con esta cuenta.',
  source_unavailable: 'La fuente no está disponible en este momento.',
  invalid_source_records: 'La fuente devolvió registros que no cumplen el contrato seguro.',
};
const platformLabel: Record<PostingAccount['platform'], string> = {
  tiktok: 'TikTok',
  youtube: 'YouTube',
  facebook: 'Facebook',
};
const unavailable = 'No disponible';
const noConnection = 'No conectada / sin verificación';
const unresolvedAccount = 'Sin cuenta verificada para esta marca.';

function FieldList({ accountContent, responsible, style, material, calendar, metrics }: {
  accountContent: ReactNode;
  responsible: string;
  style: string;
  material: string;
  calendar: string;
  metrics: string;
}) {
  return <dl className="posting-departments__fields">
    <dt>Responsable / roles</dt><dd>{responsible}</dd>
    <dt>Cuentas</dt><dd>{accountContent}</dd>
    <dt>Estilo</dt><dd>{style}</dd>
    <dt>Material</dt><dd>{material}</dd>
    <dt>Calendario</dt><dd>{calendar}</dd>
    <dt>Métricas</dt><dd>{metrics}</dd>
  </dl>;
}

function AccountList({ accounts, emptyText = unresolvedAccount }: { accounts: PostingAccount[]; emptyText?: string }) {
  if (!accounts.length) return <span className="posting-departments__none">{emptyText}</span>;
  return <>{accounts.map(account => <span className="posting-departments__account" key={account.key}>
    {platformLabel[account.platform]} · {account.displayIdentity}
    <small>{account.identityEvidence === 'coordinator_mapping' ? 'Mapeo aportado' : 'Metadata de fuente verificada'} · alias mapeados: {account.aliasesCount} · conexión runtime: desconocida</small>
  </span>)}</>;
}

/** Proposal and evidence are intentionally presented as separate registers. */
export function PostingDepartments({ ownerId, refresh }: Props) {
  const [retry, setRetry] = useState(0);
  const [registry, setRegistry] = useState<PostingRegistry>(() => loadingState(ownerId));

  useEffect(() => {
    const controller = new AbortController();
    setRegistry(loadingState(ownerId));
    if (!ownerId) {
      setRegistry({ state: 'denied', ownerId, accounts: [], excludedUnverifiable: 0 });
      return () => controller.abort();
    }
    void readPostingRegistry(ownerId, controller.signal).then(result => {
      if (!controller.signal.aborted) setRegistry(result);
    });
    return () => controller.abort();
  }, [ownerId, refresh, retry]);

  // Hide all prior-owner data on the first render after an identity switch.
  const visibleRegistry = registry.ownerId === ownerId ? registry : loadingState(ownerId);
  const kongAccounts = useMemo(
    () => visibleRegistry.state === 'ready' ? visibleRegistry.accounts.filter(a => a.brand === 'KONG' && a.platform === 'tiktok') : [],
    [visibleRegistry],
  );
  const blackRoomAccounts = useMemo(
    () => visibleRegistry.state === 'ready' ? visibleRegistry.accounts.filter(a => a.brand === 'Black Room') : [],
    [visibleRegistry],
  );
  const sourceIsUnavailable = visibleRegistry.state === 'unavailable' || visibleRegistry.state === 'error';
  const registrySummary = visibleRegistry.state === 'loading'
    ? 'Consultando registro owner-only'
    : visibleRegistry.state === 'ready'
      ? `Registro disponible · ${visibleRegistry.accounts.length} mapeos filtrados`
      : visibleRegistry.state === 'denied'
        ? 'Acceso no autorizado'
        : 'Inventario no confirmado';

  const renderCard = (
    key: string,
    title: string,
    kind: 'evidence' | 'proposal',
    fields: Parameters<typeof FieldList>[0],
    note?: string,
  ) => <article className={`posting-departments__card${kind === 'proposal' ? ' posting-departments__card--proposal' : ''}`} key={key}>
    <header className="posting-departments__card-head">
      <div><span className="posting-departments__eyebrow">POSTING · {kind === 'evidence' ? 'Evidencia / alcance' : 'Propuesta'}</span><h4>{title}</h4></div>
      <span className={`posting-departments__badge${kind === 'proposal' ? ' posting-departments__badge--proposal' : ''}`}>
        {kind === 'evidence' ? 'Solo evidencia' : 'No conectado'}
      </span>
    </header>
    <FieldList {...fields} />
    {note && <p className="posting-departments__account-proof">{note}</p>}
  </article>;

  return <section className="posting-departments" aria-labelledby="posting-departments-heading">
    <header className="posting-departments__heading">
      <div>
        <span className="posting-departments__eyebrow">Oficina online · solo lectura</span>
        <h2 id="posting-departments-heading">POSTING / Departamentos</h2>
        <p>La actividad, las identidades operativas y los resultados solo se afirman cuando una fuente los confirma. Las ideas futuras permanecen marcadas como propuestas.</p>
      </div>
      <span className="posting-departments__stamp" data-state={visibleRegistry.state} role="status">{registrySummary}</span>
    </header>

    <aside className={`posting-departments__notice${sourceIsUnavailable ? ' posting-departments__notice--warning' : ''}`}>
      <strong>Identidad no equivale a conexión</strong>
       <span>El registro requiere vínculo owner/source comprobado e identidad física verificable. Distingue el mapeo aportado de la metadata de fuente y no demuestra sesión, conexión, publicación ni actividad en runtime; sin prueba, los datos quedan como «{unavailable}».</span>
    </aside>
    {visibleRegistry.state === 'loading' && <div className="posting-departments__skeleton" aria-hidden="true"><i /><i /><i /></div>}

    {sourceIsUnavailable && <aside className="posting-departments__notice posting-departments__notice--warning" role="alert">
      <strong>Inventario sin confirmar</strong>
      <span>{visibleRegistry.state === 'unavailable' || visibleRegistry.state === 'error'
        ? reasonText[visibleRegistry.reason]
        : 'No se confirmó el inventario. Esto no significa que haya cero cuentas.'}
        {' '}Una fuente no disponible no equivale a cero cuentas.
        {visibleRegistry.state === 'unavailable' && visibleRegistry.excludedUnverifiable > 0 &&
          ` Registros excluidos como no verificables: ${visibleRegistry.excludedUnverifiable}.`}
        <br /><button type="button" className="posting-departments__retry" onClick={() => setRetry(value => value + 1)}>Reintentar lectura segura</button>
      </span>
    </aside>}
    {visibleRegistry.state === 'denied' && <p role="alert" className="posting-departments__footnote">Sesión no confirmada o acceso denegado. Se ocultan los datos del registro.</p>}

    <div className="posting-departments__sections">
      <section aria-labelledby="posting-evidence-heading">
        <header className="posting-departments__section-head">
          <h3 id="posting-evidence-heading">Evidencia recibida</h3><span>Sin inferencia de actividad</span>
        </header>
        <div className="posting-departments__cards">
          {renderCard('kong-tiktok', 'KONG', 'evidence', {
            responsible: `Roles de marketing y contenido: planificación de videos de fiestas y experiencia. Asignación de personas: ${unavailable}.`,
            accountContent: <AccountList accounts={kongAccounts} emptyText={visibleRegistry.state === 'ready' ? unresolvedAccount : 'Inventario no confirmado; no se informa un total.'} />,
            style: 'Videos de fiestas y experiencia. Guía visual aprobada: no disponible.',
            material: 'Material de fiestas/experiencia y derechos de uso: no disponible.',
            calendar: 'Calendario de publicaciones y frecuencia real: no disponible.',
            metrics: 'KPIs, alcance, reproducciones y conversiones: no disponibles.',
          }, 'KONG: la única plataforma que se mostrará para esta marca es TikTok. El mapeo de identidad no confirma conexión ni publicaciones.') }
          {renderCard('black-room-dj', 'Black Room', 'evidence', {
            responsible: `Roles de DJ y contenido: sets y clips. DJ/contact research es un rol de marketing propuesto, no personal asignado. Personas responsables: ${unavailable}.`,
            accountContent: <AccountList accounts={blackRoomAccounts} emptyText={visibleRegistry.state === 'ready' ? unresolvedAccount : 'Inventario no confirmado; no se informa un total.'} />,
            style: 'Sets y clips de DJ, con dirección visual propia y separada de KONG. Estilo aprobado: no disponible.',
            material: 'Sets, clips, masters y permisos: no disponibles.',
            calendar: 'Calendario editorial y fechas confirmadas: no disponibles.',
            metrics: 'Reproducciones, retención, interacción y resultados: no disponibles.',
          }, 'La lista de aproximadamente 15.000 DJs permanece en un Mac offline: no está importada ni accesible aquí. Sin leads, emails ni acciones de contacto.') }
        </div>
      </section>

      <section aria-labelledby="posting-proposals-heading">
        <header className="posting-departments__section-head">
          <h3 id="posting-proposals-heading">Propuestas · no son actividad</h3><span>Sin llamadas ni ejecución</span>
        </header>
        <div className="posting-departments__cards">
          {renderCard('news-clipping', 'Noticias / Clipping', 'proposal', {
            responsible: `Research y revisión editorial propuestos. Responsable asignado: ${unavailable}.`,
            accountContent: <span className="posting-departments__none">{noConnection}; plataformas y cuentas {unavailable.toLowerCase()}.</span>,
            style: 'Recopilación con fuentes y contexto; guía editorial: no disponible.',
            material: 'Fuentes/licencias y piezas aprobadas: no disponibles.',
            calendar: 'Cobertura y cadencia propuesta: no documentadas.',
            metrics: 'Métricas y objetivos: no documentados.',
          }, 'Esta ficha expresa un ámbito propuesto, no una integración, publicación o monitoreo en marcha.') }
          {renderCard('future-brands', 'Marcas futuras', 'proposal', {
            responsible: `Exploración de marca y contenido propuesta. Equipo y responsable: ${unavailable}.`,
            accountContent: <span className="posting-departments__none">{noConnection}; marca y cuentas concretas {unavailable.toLowerCase()}.</span>,
            style: 'Por definir para cada marca; no se reutiliza automáticamente el estilo de KONG o Black Room.',
            material: 'Brief, material y permisos: no disponibles.',
            calendar: 'No propuesto ni confirmado.',
            metrics: 'No definidos; no hay KPIs verificados.',
          }, 'No se inventan nombres de marca ni se sugieren identidades o perfiles que no figuren en el registro seguro.') }
        </div>
      </section>
    </div>

    <aside className="posting-departments__notice posting-departments__notice--warning">
      <strong>Outreach y costes</strong>
      <span>La investigación de DJs, outreach por email, respuestas y seguimiento para impulsar descargas de KONG son propuestas desconectadas: no hay leads importados, emails, envíos ni acciones autorizadas. Growth Scout está pendiente, sin llamada ni ejecución. Costes reales de herramientas, medios, producción y operación no disponibles; no hay promesa de coste cero ni de LLM pagado por lead.</span>
    </aside>
    <p className="posting-departments__footnote">Los conteos, si aparecen, corresponden solo a filas válidas del registro filtrado para esta identidad. No se extrapolan aliases a personas, actividad ni resultados.</p>
  </section>;
}

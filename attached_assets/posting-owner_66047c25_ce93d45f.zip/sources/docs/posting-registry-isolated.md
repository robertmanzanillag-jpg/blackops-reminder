# POSTING: isolated read-only cut

Base: `66047c25fee1f8e9700620e906cb07b0ac82dabe`, with the same tree as
`381ae4da339dc9bc7f3edbdac2c8011bee000693`. This is not an activated branch.

## Ownership blocker and passive contract

The concrete coordinator mappings exist only in `server/posting-registry.ts`.
They establish identity assertions, not ownership or runtime connection.
Existing BlackRoom configuration and its singleton gate do not provide a
persisted source/physical-account relationship to a proven request owner.
`server/single-user-owner.ts` accepts configured/local owner IDs or a username;
this is deliberately NOT used to attach these identities to authenticated users.
The Clipper/global metadata and growth-scout readers do not supply the missing
owner/source proof either.

Consequently the production reader performs no IO and returns
`owner_source_binding_unproven` and no accounts, for every authenticated caller.
The endpoint requires the existing request identity resolver, denies conflicting
owner queries before calling the reader, and never reads identity proofs from
HTTP body/query. No new store, table, default dataset, connection, permission,
credential, provider request or discovery/refresh is introduced.

The pure adapter contract accepts only proofs of existing owner-bound source
records supplied by a future separately reviewed passive reader. The current
adapter cannot produce them. Positive tests use synthetic owner/source proofs,
not real users, source data or an attestation available to browsers.

## Identity and privacy

Canonical identities are platform + verified native ID, otherwise a verified
handle with supported platform semantics. Metricool blog references are aliases
only. TikTok handles case-fold; numeric IDs remain decimal strings. Facebook
usernames ignore periods/case and numeric IDs take priority. YouTube channel
IDs are case-sensitive; handle-only Unicode semantics remain unsupported,
therefore unavailable. Conflicting proofs fail closed rather than merging.
Platform + Metricool alias resolving to multiple physical identities is also a
veto, never a replacement for the platform + physical-identity dedup key.

Only owned records contribute to accounts, aliases or excluded counts. Unknown
owners/sources are unavailable, not a verified empty inventory. Missing Facebook
identity remains unknown. A physical KONG TikTok identity has one canonical
record despite its two Metricool references. Supplied identities are never
advertised as runtime-connected, publishing or learning.

The client verifies auth owner before its sole new passive request, requires an
exact response owner, strips non-public fields, rejects oversize/malformed data,
keeps canonical identity keys, and clears prior-owner state on change/denial.
Concrete mappings are not embedded in the client or shared runtime modules.

## Product scope

Online-only department cards separate roles/responsible parties, accounts,
style, material, calendar and metrics. KONG is TikTok party/experience content;
Black Room is DJ sets/clips with a distinct style. News/clipping and future
brands stay proposals when evidence is absent. Marketing research/outreach,
responses and follow-up towards KONG downloads are disconnected proposals.
The claimed DJ list on an offline Mac is not accessed/imported; no leads/emails
or sends. Growth Scout stays pending because passive ownership is unproven.
Costs are informative, not zero-cost or paid-LLM-per-lead promises.

## Validation and review

Pure unit/auth/transport tests use fixtures and zero provider IO. The browser
harness mounts the real Agents Office page and CompanyOffice with every request
intercepted, using an existing installed Chromium, no HTTP listener or app
startup. Build checkpoints precede both harness compilation and the safe
client-only build. Logs retain exit codes. No full deployment build, backend
startup, real DB, provider, workflow, installation, activation or publication.

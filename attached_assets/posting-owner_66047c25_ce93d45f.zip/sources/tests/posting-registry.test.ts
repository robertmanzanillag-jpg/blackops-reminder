import assert from "node:assert/strict";
import test from "node:test";
import type { Request, Response } from "express";
import { createPostingRegistryHandler } from "../server/posting-registry-routes";
import { MAX_POSTING_SOURCE_RECORDS, normalizePostingIdentity, projectPostingRegistry,
  readExistingPostingSources, type ExistingOwnedPostingSource } from "../server/posting-registry";

const source = (overrides: Partial<ExistingOwnedPostingSource> = {}): ExistingOwnedPostingSource => ({
  ownerId: "owner-a", sourceId: "existing-source-a", ownershipEvidence: "existing-owner-source",
  platform: "tiktok", metricoolBlogId: "6475033", handle: "@KongNightlife", handleVerified: true, ...overrides,
});
const project = (rows: ExistingOwnedPostingSource[], owner = "owner-a") => projectPostingRegistry(owner, { state: "available", records: rows });
async function request(owner: string, query: Record<string, unknown> = {}, reader = async () => ({ state: "available" as const, records: [source()] })) {
  let code = 200, body: any, calls = 0;
  const headers: Record<string, unknown> = {};
  const req = { query } as unknown as Request;
  const res = { setHeader: (key: string, value: unknown) => { headers[key] = value; },
    status: (value: number) => { code = value; return res; }, json: (value: unknown) => { body = value; return res; } } as unknown as Response;
  await createPostingRegistryHandler(() => { if (!owner) throw new Error("no auth"); return owner; },
    async () => { calls++; return reader(); })(req, res);
  return { code, body, calls, headers };
}

test("runtime source remains unavailable for any authenticated user; no owner/source proof is invented", async () => {
  const realRead = await readExistingPostingSources();
  for (const owner of ["owner-a", "owner-b", "robert", "mock-user-123", "unknown"]) {
    const result = projectPostingRegistry(owner, realRead);
    assert.equal(result.status, "unavailable"); assert.equal(result.reason, "owner_source_binding_unproven");
    assert.deepEqual(result.accounts, []);
  }
});
test("two Metricool references to one verified TikTok identity count once, never by blog ID", () => {
  const result = project([source(), source({ sourceId: "existing-source-b", metricoolBlogId: "6431692", handle: "kongnightlife" })]);
  assert.equal(result.accounts.length, 1); assert.equal(result.accounts[0].aliasesCount, 2);
  assert.equal(result.accounts[0].key, "tiktok:handle:kongnightlife");
  assert.equal(result.accounts[0].runtimeConnection, "unknown");
});
test("verified native identity links handle-only alias without double counting", () => {
  const result = project([source({ nativeId: "123456789", nativeIdVerified: true }),
    source({ metricoolBlogId: "6431692" }), source()]);
  assert.equal(result.accounts.length, 1); assert.equal(result.accounts[0].key, "tiktok:id:123456789");
  assert.equal(result.accounts[0].aliasesCount, 2);
});
test("multiuser alias overlap cannot assign or disclose another owner's records or counts", () => {
  const rows = [source(), source({ ownerId: "owner-b", sourceId: "b", metricoolBlogId: "6431692" })];
  for (const owner of ["owner-a", "owner-b"]) {
    const result = project(rows, owner);
    assert.equal(result.accounts.length, 1); assert.equal(result.accounts[0].aliasesCount, 1);
    assert.equal(result.excludedUnverifiable, 0);
    assert.ok(!JSON.stringify(result).includes(owner === "owner-a" ? "owner-b" : "owner-a"));
  }
  assert.deepEqual(project(rows, "unknown").accounts, []);
  assert.equal(project(rows, "unknown").status, "unavailable");
});
test("missing/mismatched owner/source proof, identity verification, aliases or physical handle yields no data", () => {
  const rows = [source({ ownerId: "" }), source({ sourceId: "" }),
    source({ ownershipEvidence: "authenticated" as any }), source({ handleVerified: false }),
    source({ handle: "@different" }), source({ metricoolBlogId: "unknown" }),
    source({ platform: "facebook" }), source({ sourceId: "name-is-not-proof", handle: "" })];
  assert.deepEqual(project(rows).accounts, []);
});
test("conflicting native IDs on one verified handle fail closed", () => {
  const result = project([source({ nativeId: "111", nativeIdVerified: true }),
    source({ nativeId: "222", nativeIdVerified: true, metricoolBlogId: "6431692" }), source()]);
  assert.deepEqual(result.accounts, []);
});
test("native ID collision across brands is not counted twice or assigned silently", () => {
  const result = project([source({ nativeId: "111", nativeIdVerified: true }),
    source({ metricoolBlogId: "6585226", handle: "blackroom.clipss", nativeId: "111", nativeIdVerified: true })]);
  assert.deepEqual(result.accounts, []);
});
test("one platform/alias asserting two Facebook native identities is rejected, not deduplicated by blog", () => {
  const result = project([
    source({ platform: "facebook", metricoolBlogId: "6585226", handle: undefined, nativeId: "101", nativeIdVerified: true }),
    source({ platform: "facebook", metricoolBlogId: "6585226", handle: undefined, nativeId: "202", nativeIdVerified: true, sourceId: "existing-source-b" }),
  ]);
  assert.equal(result.status, "unavailable"); assert.deepEqual(result.accounts, []);
  assert.equal(result.excludedUnverifiable, 2);
});
test("a consistent verified Facebook native ID is counted once with folded handle aliases", () => {
  const result = project([
    source({ platform: "facebook", metricoolBlogId: "6585226", handle: "Black.Room", nativeId: "101", nativeIdVerified: true }),
    source({ platform: "facebook", metricoolBlogId: "6585226", handle: "blackroom", sourceId: "existing-source-b" }),
  ]);
  assert.equal(result.status, "ready"); assert.equal(result.accounts.length, 1);
  assert.equal(result.accounts[0].key, "facebook:id:101");
  assert.equal(result.accounts[0].identityEvidence, "verified_source_metadata");
});
test("Black Room only exposes proven identities; Facebook has no fabricated ID", () => {
  const result = project([source({ metricoolBlogId: "6585226", handle: "BLACKROOM.CLIPSS" }),
    source({ metricoolBlogId: "6585226", platform: "youtube", handle: undefined, nativeId: "UCi__qHBfHLlYg0fu86BUA8g", nativeIdVerified: true }),
    source({ metricoolBlogId: "6585226", platform: "facebook", handle: undefined })]);
  assert.equal(result.accounts.length, 2); assert.ok(result.accounts.every(row => row.brand === "Black Room"));
  assert.ok(!result.accounts.some(row => row.platform === "facebook"));
});
test("platform semantics: TikTok case fold, Facebook period fold, native YouTube case preserved", () => {
  assert.deepEqual(normalizePostingIdentity("tiktok", undefined, "@KONGNightlife"), { native: undefined, handle: "kongnightlife" });
  assert.deepEqual(normalizePostingIdentity("facebook", undefined, "Black.Room"), { native: undefined, handle: "blackroom" });
  assert.equal(normalizePostingIdentity("youtube", "uci__qhbfhllYG0FU86bua8g"), null);
  assert.equal(normalizePostingIdentity("youtube", undefined, "@SomeHandle"), null);
  assert.equal(normalizePostingIdentity("tiktok", "0", "https://tiktok.com/@kongnightlife"), null);
  assert.equal(normalizePostingIdentity("tiktok", undefined, "bad."), null);
});
test("row/owner/string limits reject oversized data without truncating ownership evidence", () => {
  assert.equal(project(Array.from({ length: MAX_POSTING_SOURCE_RECORDS + 1 }, () => source())).status, "unavailable");
  assert.deepEqual(project([source({ sourceId: "x".repeat(129) }), source({ handle: "x".repeat(1000) })]).accounts, []);
  assert.equal(project([source()], "x".repeat(129)).status, "unavailable");
  assert.equal(normalizePostingIdentity("facebook", "9".repeat(33)), null);
  const facebookSources = Array.from({ length: 33 }, (_, n) => source({ platform: "facebook",
    metricoolBlogId: "6585226", handle: undefined, nativeId: String(n + 100), nativeIdVerified: true }));
  assert.equal(project(facebookSources).status, "unavailable");
});
test("public projection contains no raw sources/aliases/tokens/extra metadata", () => {
  const result = project([Object.assign(source(), { token: "fixture-private-token", email: "private@example.invalid", label: "PRIVATE_LABEL" })]);
  for (const forbidden of ["6475033", "existing-source-a", "fixture-private-token", "private@example.invalid", "PRIVATE_LABEL"]) {
    assert.ok(!JSON.stringify(result).includes(forbidden));
  }
});
test("route 401/403 gates run before source reader and query/body never grant another owner", async () => {
  const unauth = await request(""); assert.equal(unauth.code, 401); assert.equal(unauth.calls, 0);
  const denied = await request("owner-a", { ownerId: "owner-b", metricoolBlogId: "6475033" });
  assert.equal(denied.code, 403); assert.equal(denied.calls, 0);
  const result = await request("owner-b", { blogId: "6475033" });
  assert.equal(result.code, 200); assert.deepEqual(result.body.accounts, []);
  assert.equal(result.headers["Cache-Control"], "private, no-store");
});
test("source missing/error stays unknown and does not seed/refresh/persist", async () => {
  const result = await request("owner-a", {}, async () => { throw new Error("missing source/table"); });
  assert.equal(result.code, 503); assert.deepEqual(result.body.accounts, []);
  assert.equal(result.body.reason, "source_unavailable");
});
test("registry and route have zero provider IO, including repeated reads and denied requests", async () => {
  const previous = globalThis.fetch;
  let providerCalls = 0;
  globalThis.fetch = async () => { providerCalls++; throw new Error("provider IO forbidden"); };
  try {
    for (let n = 0; n < 3; n++) {
      const req = await request("owner-a", {}, readExistingPostingSources as any);
      assert.deepEqual(req.body.accounts, []);
      await request("");
      project([source(), source({ metricoolBlogId: "6431692" })]);
    }
    assert.equal(providerCalls, 0);
  } finally { globalThis.fetch = previous; }
});

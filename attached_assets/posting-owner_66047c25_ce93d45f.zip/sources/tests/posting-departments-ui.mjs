// Offline harness: real /agents-office page + CompanyOffice; all requests intercepted.
import { build } from 'esbuild';
import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

if (!process.env.AGENTS_WORLD_BROWSER) throw new Error('Existing Chromium required; no installation/download.');
const output = path.resolve('.local/posting-harness');
await mkdir(output, { recursive: true });
await build({
  entryPoints: ['tests/harness/agents-world-integrated.tsx'], bundle: true, format: 'esm', platform: 'browser', jsx: 'automatic',
  outfile: path.join(output, 'harness.js'),
  alias: { '@': path.resolve('client/src'), '@shared': path.resolve('shared') },
  define: { 'process.env.NODE_ENV': '"test"', 'import.meta.env.DEV': 'false' },
});
const js = await readFile(path.join(output, 'harness.js'), 'utf8');
const css = await readFile(path.join(output, 'harness.css'), 'utf8');
const html = '<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="/harness.css"><body style="margin:0;background:#080e18;color:#d7e7ef"><div id="root"></div><script type="module" src="/harness.js"></script></body></html>';
const origin = 'http://posting-harness.invalid';
const browser = await chromium.launch({ executablePath: process.env.AGENTS_WORLD_BROWSER, headless: true,
  args: ['--no-sandbox', '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader',
    '--disable-background-networking', '--disable-component-update', '--disable-sync'] });
let checks = 0;
const summaries = [];
function check(value, label) { assert.ok(value, label); checks++; console.log(`PASS ${label}`); }
try {
  for (const mode of ['ready', 'unknown', 'denied', 'foreign', 'oversized', 'mobile']) {
    const context = await browser.newContext({ viewport: mode === 'mobile' ? { width: 390, height: 844 } : { width: 1440, height: 1000 },
      reducedMotion: 'reduce', serviceWorkers: 'block' });
    const page = await context.newPage();
    const errors = [], forbidden = [], requests = [];
    page.on('pageerror', error => errors.push(error.message));
    const state = { owner: 'fixture-user', expired: false };
    await page.route('**/*', async route => {
      const req = route.request(), url = new URL(req.url()), p = url.pathname;
      requests.push(p);
      if (url.origin !== origin || req.method() !== 'GET') { forbidden.push(p); return route.abort(); }
      if (p === '/agents-office') return route.fulfill({ contentType: 'text/html', body: html });
      if (p === '/harness.js') return route.fulfill({ contentType: 'text/javascript', body: js });
      if (p === '/harness.css') return route.fulfill({ contentType: 'text/css', body: css });
      if (p === '/api/auth/me') return route.fulfill({ contentType: 'application/json',
        body: JSON.stringify(state.expired ? { authenticated: false } : { authenticated: true, user: { id: state.owner } }) });
      if (p === '/api/projects' || p === '/api/tasks') return route.fulfill({ contentType: 'application/json', body: '[]' });
      if (p === '/api/agents-office/posting-registry') {
        const account = { key: 'tiktok:id:70001', platform: 'tiktok', brand: 'KONG', displayIdentity: '@fixture_kong',
          identityEvidence: 'coordinator_mapping', runtimeConnection: 'unknown', aliasesCount: 2 };
        const ready = state.owner === 'fixture-user' && !['unknown', 'denied', 'foreign'].includes(mode);
        return route.fulfill({ status: mode === 'denied' ? 403 : 200, contentType: 'application/json',
          body: JSON.stringify({ ownerId: mode === 'foreign' ? 'other-owner' : state.owner,
            status: ready ? 'ready' : 'unavailable', reason: ready ? null : 'owner_source_binding_unproven',
            accounts: ready ? (mode === 'oversized' ? Array.from({ length: 33 }, () => account) : [account]) : [],
            excludedUnverifiable: 0 }) });
      }
      if (p.startsWith('/api/blackroom-agent') || /growth-scout|refresh|\/run|\/start|metricool/.test(p)) forbidden.push(p);
      return route.fulfill({ status: 404, contentType: 'application/json', body: '{"error":"offline fixture not provided"}' });
    });
    await page.goto(`${origin}/agents-office`);
    const toggle = page.getByRole('button', { name: /Vista 3D/i });
    await toggle.first().click();
    const section = page.locator('.posting-departments');
    await section.waitFor();
    await page.waitForFunction(() => document.querySelector('.posting-departments__stamp')?.getAttribute('data-state') !== 'loading');
    check(await section.getByRole('heading', { name: 'KONG', exact: true }).count() === 1, `${mode}: unique KONG department`);
    check(await section.getByRole('heading', { name: 'Black Room', exact: true }).count() === 1, `${mode}: unique Black Room department`);
    check(await section.getByRole('heading', { name: 'Noticias / Clipping', exact: true }).count() === 1, `${mode}: news department`);
    check(await section.getByRole('heading', { name: 'Marcas futuras', exact: true }).count() === 1, `${mode}: proposed future brands`);
    for (const field of ['Responsable / roles', 'Cuentas', 'Estilo', 'Material', 'Calendario', 'Métricas']) {
      check(await section.locator('dt').filter({ hasText: field }).count() === 4, `${mode}: distinct ${field}`);
    }
    check((await section.innerText()).includes('Mac offline'), `${mode}: no imported DJ list`);
    check((await section.innerText()).includes('Growth Scout está pendiente'), `${mode}: scout not executed`);
    check((await section.innerText()).includes('no hay promesa de coste cero'), `${mode}: honest costs`);
    if (mode === 'ready' || mode === 'mobile') {
      check(await section.locator('.posting-departments__account').count() === 1, `${mode}: one physical account, not two aliases`);
      check((await section.innerText()).includes('@fixture_kong'), `${mode}: verified owner fixture shown`);
      check(!(await section.innerText()).includes('conexión runtime: online'), `${mode}: runtime connection not invented`);
      state.owner = 'fixture-other';
      await page.evaluate(() => window.setFixtureOwner('fixture-other'));
      await page.waitForFunction(() => !document.querySelector('.posting-departments')?.textContent?.includes('@fixture_kong'));
      check(!(await section.innerText()).includes('@fixture_kong'), `${mode}: owner change clears old data`);
      state.expired = true;
      await page.evaluate(() => window.setFixtureOwner(''));
      await page.waitForTimeout(100);
      check(await page.locator('.posting-departments__account').count() === 0, `${mode}: logout has no private account`);
    } else {
      check(await section.locator('.posting-departments__account').count() === 0, `${mode}: unavailable/foreign/denied has no accounts`);
    }
    if (mode === 'unknown' || mode === 'oversized') check((await section.innerText()).includes('no equivale a cero cuentas'), `${mode}: unknown not zero`);
    check(forbidden.length === 0, `${mode}: no unsafe/provider/network request`);
    check(errors.length === 0, `${mode}: no page errors`);
    summaries.push({ mode, requests, forbidden, errors });
    if (mode === 'unknown') await page.screenshot({ path: path.join(output, 'unknown-desktop.png'), fullPage: true });
    if (mode === 'mobile') await page.screenshot({ path: path.join(output, 'owner-mobile.png'), fullPage: true });
    await context.close();
  }
  await writeFile(path.join(output, 'results.json'), JSON.stringify({ checks, summaries }, null, 2));
  console.log(`CHECKS=${checks} SCENARIOS=${summaries.length} PROVIDER_IO=0`);
} finally { await browser.close(); }

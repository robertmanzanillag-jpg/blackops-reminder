import assert from "node:assert/strict";
import test from "node:test";
import { readPostingRegistry } from "../client/src/lib/posting-registry";

const account = { key: "tiktok:id:70001", platform: "tiktok", brand: "KONG", displayIdentity: "@fixture_kong",
  identityEvidence: "coordinator_mapping", runtimeConnection: "unknown", aliasesCount: 2 };
const payload = (overrides: Record<string, unknown> = {}) => ({
  ownerId: "fixture-owner", status: "ready", reason: null, accounts: [account], excludedUnverifiable: 0, ...overrides,
});
async function withFetch(body: unknown, options: { authOwner?: string; authStatus?: number; registryStatus?: number; abort?: boolean } = {}) {
  const original = globalThis.fetch, requests: string[] = [], controller = new AbortController();
  globalThis.fetch = async (url) => {
    requests.push(String(url));
    if (String(url) === "/api/auth/me") {
      if (options.abort) controller.abort();
      return new Response(JSON.stringify({ authenticated: true, user: { id: options.authOwner || "fixture-owner" } }),
        { status: options.authStatus || 200, headers: { "content-type": "application/json" } });
    }
    assert.equal(String(url), "/api/agents-office/posting-registry", "no other endpoint");
    return new Response(JSON.stringify(body), { status: options.registryStatus || 200, headers: { "content-type": "application/json" } });
  };
  try { return { result: await readPostingRegistry("fixture-owner", controller.signal), requests }; }
  finally { globalThis.fetch = original; }
}
test("client preserves native canonical key and receives only sanitised public fields", async () => {
  const { result, requests } = await withFetch(payload({ accounts: [{ ...account, token: "PRIVATE", sourceId: "SECRET_SOURCE", blogId: "SECRET_ALIAS" }] }));
  assert.equal(result.state, "ready"); assert.equal(result.accounts[0].key, account.key);
  assert.deepEqual(requests, ["/api/auth/me", "/api/agents-office/posting-registry"]);
  for (const privateValue of ["PRIVATE", "SECRET_SOURCE", "SECRET_ALIAS"]) assert.ok(!JSON.stringify(result).includes(privateValue));
});
test("unknown auth owner, 401 or aborted auth never fetches the registry", async () => {
  for (const options of [{ authOwner: "other-owner" }, { authStatus: 401 }, { abort: true }]) {
    const { result, requests } = await withFetch(payload(), options);
    assert.equal(result.state, "denied"); assert.deepEqual(result.accounts, []);
    assert.deepEqual(requests, ["/api/auth/me"]);
  }
});
test("response owner mismatch and endpoint 401/403 never expose accounts", async () => {
  for (const options of [{ body: payload({ ownerId: "foreign" }) }, { status: 401 }, { status: 403 }]) {
    const { result } = await withFetch(options.body || payload(), { registryStatus: options.status });
    assert.equal(result.state, "denied"); assert.deepEqual(result.accounts, []);
  }
});
test("source unknown is not a verified zero-account inventory", async () => {
  const { result } = await withFetch(payload({ status: "unavailable", reason: "owner_source_binding_unproven", accounts: [] }));
  assert.equal(result.state, "unavailable"); assert.deepEqual(result.accounts, []);
});
test("duplicate canonical ID, limits, invalid evidence and forged inventory fail closed", async () => {
  const invalid = [
    payload({ accounts: [account, { ...account, displayIdentity: "@different_display" }] }),
    payload({ accounts: Array.from({ length: 33 }, () => account) }),
    payload({ accounts: [{ ...account, key: "tiktok:id:" + "x".repeat(100) }] }),
    payload({ accounts: [{ ...account, displayIdentity: "x".repeat(97) }] }),
    payload({ accounts: [{ ...account, displayIdentity: "@fixture\u0000_kong" }] }),
    payload({ accounts: [{ ...account, runtimeConnection: "online" }] }),
    payload({ accounts: [{ ...account, platform: "youtube" }] }),
    payload({ accounts: [{ ...account, aliasesCount: 0 }] }),
    payload({ status: "unavailable", reason: "owner_source_binding_unproven" }),
  ];
  for (const body of invalid) {
    const { result } = await withFetch(body);
    assert.equal(result.state, "unavailable"); assert.deepEqual(result.accounts, []);
  }
});

import type { PostingAccount, PostingBrand, PostingPlatform, PostingRegistrySnapshot } from "../shared/posting-registry";

// Coordinator-supplied mappings, NOT proof of ownership or runtime connectivity.
// Never imported into the browser. Blog references are aliases, never identities.
const mappings = [
  { brand: "KONG", blogs: ["6475033", "6431692"], platform: "tiktok", handle: "kongnightlife" },
  { brand: "Black Room", blogs: ["6585226"], platform: "tiktok", handle: "blackroom.clipss" },
  { brand: "Black Room", blogs: ["6585226"], platform: "youtube", nativeId: "UCi__qHBfHLlYg0fu86BUA8g" },
  { brand: "Black Room", blogs: ["6585226"], platform: "facebook" },
] as const;
export const MAX_POSTING_SOURCE_RECORDS = 128;
export const MAX_POSTING_ACCOUNTS = 32;

/**
 * Adapter boundary, not a new persistence schema or a client-provided attestation.
 * Only a separately reviewed reader of EXISTING owner-bound source records may
 * supply these proofs. No current global BlackRoom/Clipper source proves this.
 */
export interface ExistingOwnedPostingSource {
  ownerId: string;
  sourceId: string;
  ownershipEvidence: "existing-owner-source";
  platform: PostingPlatform;
  metricoolBlogId: string;
  nativeId?: string;
  nativeIdVerified?: boolean;
  handle?: string;
  handleVerified?: boolean;
}
export type PostingSourceRead =
  | { state: "unavailable"; reason: "owner_source_binding_unproven" | "source_unavailable" }
  | { state: "available"; records: readonly ExistingOwnedPostingSource[] };

function bounded(value: unknown, max = 128): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= max
    && value.trim() === value && !/[\u0000-\u001f\u007f]/.test(value);
}

export function normalizePostingIdentity(platform: PostingPlatform, nativeId?: unknown, handle?: unknown) {
  let native: string | undefined;
  let username: string | undefined;
  if ((platform === "tiktok" || platform === "facebook") && bounded(nativeId, 32)
    && /^[1-9][0-9]{0,31}$/.test(nativeId)) native = nativeId;
  // Channel IDs are case-sensitive. Never lower-case them or treat a blog as one.
  if (platform === "youtube" && bounded(nativeId, 24) && /^UC[A-Za-z0-9_-]{22}$/.test(nativeId)) native = nativeId;
  if (bounded(handle, 64)) {
    const value = handle.replace(/^@/, "");
    if (platform === "tiktok" && /^[A-Za-z0-9_][A-Za-z0-9_.]{1,23}$/.test(value) && !value.endsWith(".")) username = value.toLowerCase();
    // Facebook usernames ignore case and periods; native numeric IDs take priority.
    if (platform === "facebook" && /^[A-Za-z0-9.]{5,50}$/.test(value)
      && value.replace(/\./g, "").length >= 5) username = value.replace(/\./g, "").toLowerCase();
    // YouTube handle-only records are unsupported until its broader Unicode
    // identity semantics are separately verified. The supplied channel uses ID.
  }
  return native || username ? { native, handle: username } : null;
}

export function unavailablePostingRegistry(ownerId: string, reason: PostingRegistrySnapshot["reason"]): PostingRegistrySnapshot {
  return { ownerId, status: "unavailable", reason, accounts: [], excludedUnverifiable: 0 };
}

/**
 * Explicit fail-closed runtime adapter. Existing sources are global/configured,
 * with no proven persisted owner/source/physical-account relationship. Do not
 * use isConfiguredSingleUserOwner, a username, getSystemUserId, an authenticated
 * user, or a matching project name to assign coordinator identities to someone.
 * No DB/DDL/seeding/files/provider IO is performed here.
 */
export async function readExistingPostingSources(): Promise<PostingSourceRead> {
  return { state: "unavailable", reason: "owner_source_binding_unproven" };
}

export function projectPostingRegistry(ownerId: string, source: PostingSourceRead): PostingRegistrySnapshot {
  if (!bounded(ownerId)) return unavailablePostingRegistry("", "owner_source_binding_unproven");
  if (source.state !== "available") return unavailablePostingRegistry(ownerId, source.reason);
  if (!Array.isArray(source.records) || source.records.length > MAX_POSTING_SOURCE_RECORDS) {
    return unavailablePostingRegistry(ownerId, "invalid_source_records");
  }
  const candidates: Array<{ brand: PostingBrand; platform: PostingPlatform; native?: string; handle?: string; alias: string }> = [];
  let excluded = 0;
  let ownedSources = 0;
  for (const row of source.records) {
    // Never count/expose other owners, even as excluded records.
    if (!row || row.ownerId !== ownerId) continue;
    if (!bounded(row.sourceId) || row.ownershipEvidence !== "existing-owner-source") { excluded++; continue; }
    ownedSources++;
    const mapping = mappings.find(m => m.platform === row.platform && (m.blogs as readonly string[]).includes(row.metricoolBlogId));
    const identity = normalizePostingIdentity(row.platform, row.nativeIdVerified === true ? row.nativeId : undefined,
      row.handleVerified === true ? row.handle : undefined);
    if (!mapping || !identity
      || ("handle" in mapping && identity.handle !== mapping.handle)
      || ("nativeId" in mapping && identity.native !== mapping.nativeId)) { excluded++; continue; }
    candidates.push({ brand: mapping.brand, platform: row.platform, ...identity, alias: row.metricoolBlogId });
  }
  // Link verified handle-only aliases to a verified native ID when unambiguous.
  // Conflicting native IDs for one handle are not silently merged.
  const handleIds = new Map<string, Set<string>>();
  for (const row of candidates) {
    if (!row.handle || !row.native) continue;
    const key = `${row.platform}:${row.handle}`;
    const ids = handleIds.get(key) || new Set<string>(); ids.add(row.native); handleIds.set(key, ids);
  }
  const groups = new Map<string, { account: PostingAccount; aliases: Set<string>; conflict: boolean; count: number }>();
  const physicalKey = (row: typeof candidates[number]) => {
    const ids = row.handle ? handleIds.get(`${row.platform}:${row.handle}`) : undefined;
    const native = row.native || (ids?.size === 1 ? [...ids][0] : undefined);
    return `${row.platform}:${native ? `id:${native}` : `handle:${row.handle}`}`;
  };
  // Alias consistency is a veto, NOT the physical-identity dedup key.
  // A platform/alias cannot attest two different physical accounts.
  const aliasIdentities = new Map<string, Set<string>>();
  for (const row of candidates) {
    const key = `${row.platform}:${row.alias}`;
    const identities = aliasIdentities.get(key) || new Set<string>();
    identities.add(physicalKey(row)); aliasIdentities.set(key, identities);
  }
  for (const row of candidates) {
    const ids = row.handle ? handleIds.get(`${row.platform}:${row.handle}`) : undefined;
    if (ids && ids.size > 1) { excluded++; continue; }
    if (aliasIdentities.get(`${row.platform}:${row.alias}`)!.size > 1) { excluded++; continue; }
    const native = row.native || (ids?.size === 1 ? [...ids][0] : undefined);
    const key = physicalKey(row);
    const group = groups.get(key);
    if (group) {
      group.count++; group.aliases.add(row.alias);
      if (group.account.brand !== row.brand) group.conflict = true;
    } else groups.set(key, {
      account: { key, platform: row.platform, brand: row.brand,
        displayIdentity: row.handle ? `@${row.handle}` : native!,
        identityEvidence: row.platform === "facebook" ? "verified_source_metadata" : "coordinator_mapping",
        runtimeConnection: "unknown", aliasesCount: 0 },
      aliases: new Set([row.alias]), conflict: false, count: 1,
    });
  }
  const accounts: PostingAccount[] = [];
  for (const group of groups.values()) {
    if (group.conflict) { excluded += group.count; continue; }
    accounts.push({ ...group.account, aliasesCount: group.aliases.size });
  }
  if (accounts.length > MAX_POSTING_ACCOUNTS) return unavailablePostingRegistry(ownerId, "invalid_source_records");
  if (!accounts.length) return {
    ...unavailablePostingRegistry(ownerId, ownedSources ? "invalid_source_records" : "owner_source_binding_unproven"),
    excludedUnverifiable: excluded,
  };
  accounts.sort((a, b) => a.key.localeCompare(b.key));
  return { ownerId, status: "ready", reason: null, accounts, excludedUnverifiable: excluded };
}

import type { Express, Request, Response } from "express";
import { projectPostingRegistry, readExistingPostingSources, type PostingSourceRead } from "./posting-registry";

type AuthResolver = (req: Request) => string;
type Reader = () => Promise<PostingSourceRead>;

/** Dependency-injected for offline auth/route tests; never accepts proofs from HTTP. */
export function createPostingRegistryHandler(resolveOwner: AuthResolver, readSources: Reader = readExistingPostingSources) {
  return async (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("Vary", "Cookie, Authorization");
    let owner: string;
    try { owner = resolveOwner(req); } catch { res.status(401).json({ error: "Authentication required" }); return; }
    if (!owner || owner.length > 128 || owner.trim() !== owner || /[\u0000-\u001f\u007f]/.test(owner)) {
      res.status(401).json({ error: "Authentication required" }); return;
    }
    if (req.query?.ownerId !== undefined && req.query.ownerId !== owner) {
      res.status(403).json({ error: "Owner mismatch" }); return;
    }
    try {
      res.json(projectPostingRegistry(owner, await readSources()));
    } catch {
      res.status(503).json({ ownerId: owner, status: "unavailable", reason: "source_unavailable", accounts: [], excludedUnverifiable: 0 });
    }
  };
}

export function registerPostingRegistryRoutes(app: Express, resolveOwner: AuthResolver) {
  app.get("/api/agents-office/posting-registry", createPostingRegistryHandler(resolveOwner));
}
